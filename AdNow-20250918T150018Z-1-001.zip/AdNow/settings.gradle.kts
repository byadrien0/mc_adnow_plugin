rootProject.name = "AdNow"
