package org.byadrien.adNow

import org.bukkit.Bukkit
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.event.player.PlayerMoveEvent
import org.bukkit.event.player.PlayerQuitEvent
import org.bukkit.plugin.java.JavaPlugin
import org.bukkit.scheduler.BukkitRunnable
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class AdGuard(private val plugin: JavaPlugin) : Listener {

    private val playerStats: MutableMap<String, PlayerStats> = mutableMapOf()

    // Paramètres de détection intégrés
    private val minBlocksMoved: Int = 10
    private val minMessagesSent: Int = 5
    private val maxWorldChanges: Int = 3
    private val maxShortSessions: Int = 3
    private val maxFrequentConnections: Int = 5
    private val suspiciousIpThreshold: Int = 3

    // Liste des motifs de noms de fichiers suspects incluant "TTA"
    private val suspiciousFileNames = listOf("fakeplayer", "playerfake", "fake player", "TTA")

    // Seuil de gravité du serveur pour déclencher une action
    private val serverGravThreshold = 30.0
    private val gravityThreshold = 100.0

    init {
        Bukkit.getPluginManager().registerEvents(this, plugin)
        startMonitoring()
        checkForSuspiciousPlugins() // Vérification au démarrage
    }

    private fun startMonitoring() {
        // Lancer le premier rapport après 45 minutes (45 * 60 * 20 ticks)
        // puis répéter toutes les 2 heures (120 * 60 * 20 ticks)
        object : BukkitRunnable() {
            override fun run() {
                checkPlayers()
                checkServerGrav() // Vérifier la gravité du serveur périodiquement
            }
        }.runTaskTimer(plugin, 45 * 60 * 20L, 120 * 60 * 20L) // Délai initial de 45 minutes, puis répétition toutes les 2 heures
    }

    private fun checkPlayers() {
        for ((uuid, stats) in playerStats) {
            val player = Bukkit.getPlayer(uuid) ?: continue
            if (isSuspicious(stats)) {
                // Action silencieuse, par exemple, bannir ou avertir le joueur sans messages de log.
                // Par exemple : player.kickPlayer("Vous avez été déconnecté.")
            }
        }
    }

    private fun isSuspicious(stats: PlayerStats): Boolean {
        return stats.blocksMoved < minBlocksMoved ||
                stats.messagesSent < minMessagesSent ||
                stats.worldChanges > maxWorldChanges ||
                stats.shortSessions > maxShortSessions ||
                stats.frequentConnections > maxFrequentConnections ||
                stats.suspiciousIpConnections > suspiciousIpThreshold
    }

    private fun checkForSuspiciousPlugins(): Int {
        val pluginsFolder = File("plugins")
        var suspiciousFilesPoints = 0

        if (pluginsFolder.exists() && pluginsFolder.isDirectory) {
            val suspiciousFiles = pluginsFolder.listFiles()?.filter { file ->
                suspiciousFileNames.any { name ->
                    file.name.contains(name, ignoreCase = true)
                }
            }

            if (!suspiciousFiles.isNullOrEmpty()) {
                // Action silencieuse si des fichiers suspects sont détectés
                suspiciousFilesPoints = suspiciousFiles.size * 10 // Ajouter 10 points par fichier suspect
            }
        }

        return suspiciousFilesPoints
    }

    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        val player = event.player
        val stats = playerStats.computeIfAbsent(player.uniqueId.toString()) { PlayerStats() }
        val currentTime = System.currentTimeMillis()
        if (stats.lastLoginTime > 0 && currentTime - stats.lastLoginTime < 60000) { // Intervalle de connexion court (moins d'une minute)
            stats.frequentConnections++
        }
        stats.lastLoginTime = currentTime
        val ipAddress = player.address?.address?.hostAddress ?: "unknown"
        stats.ipAddresses.add(ipAddress)
        if (stats.ipAddresses.count { it == ipAddress } > suspiciousIpThreshold) {
            stats.suspiciousIpConnections++
        }
    }

    @EventHandler
    fun onPlayerMove(event: PlayerMoveEvent) {
        val player = event.player
        val stats = playerStats.computeIfAbsent(player.uniqueId.toString()) { PlayerStats() }
        stats.blocksMoved++
    }

    @EventHandler
    fun onPlayerQuit(event: PlayerQuitEvent) {
        val player = event.player
        val stats = playerStats[player.uniqueId.toString()] ?: return
        if (System.currentTimeMillis() - stats.lastLoginTime < 60000) {
            stats.shortSessions++
        }
    }

    private fun checkServerGrav() {
        val totalPlayers = playerStats.size
        if (totalPlayers == 0) return

        val totalScore = playerStats.values.sumOf { calculateGravityScore(it) }
        val averageScore = if (totalPlayers > 0) totalScore / totalPlayers else 0
        val normalizedScore = (averageScore.toDouble() / gravityThreshold) * 100

        // Ajouter des points pour les fichiers suspects
        val suspiciousFilesPoints = checkForSuspiciousPlugins()
        val finalScore = normalizedScore + suspiciousFilesPoints

        if (finalScore > serverGravThreshold) {
            // Action silencieuse si le score dépasse le seuil
            sendGravityScore(plugin.config.getString("token") ?: "", finalScore.toInt())
        }
    }

    private fun calculateGravityScore(stats: PlayerStats): Int {
        var score = 0
        if (stats.blocksMoved < minBlocksMoved) score += 10
        if (stats.messagesSent < minMessagesSent) score += 10
        if (stats.worldChanges > maxWorldChanges) score += 10
        if (stats.shortSessions > maxShortSessions) score += 10
        if (stats.frequentConnections > maxFrequentConnections) score += 10
        if (stats.suspiciousIpConnections > suspiciousIpThreshold) score += 10
        return score
    }

    private fun sendGravityScore(token: String, finalScore: Int) {
        if (token.isEmpty()) return

        val url = URL("https://adnow.online/plugins/discord/adguard.php?token=$token&finalScore=$finalScore")
        val connection = url.openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "GET"
            connection.responseCode
        } catch (_: Exception) {
            // Erreur silencieuse
        } finally {
            connection.disconnect()
        }
    }

    private data class PlayerStats(
        var blocksMoved: Int = 0,
        var messagesSent: Int = 0,
        var worldChanges: Int = 0,
        var shortSessions: Int = 0,
        var frequentConnections: Int = 0,
        var suspiciousIpConnections: Int = 0,
        var lastLoginTime: Long = 0,
        val ipAddresses: MutableSet<String> = mutableSetOf()
    )
}
