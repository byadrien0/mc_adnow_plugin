package org.byadrien.adNow

import org.bukkit.Bukkit
import org.bukkit.plugin.java.JavaPlugin
import org.bukkit.configuration.file.YamlConfiguration
import org.bukkit.scheduler.BukkitRunnable
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.logging.Level
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URLEncoder

class AdNow : JavaPlugin() {

    companion object {
        const val PLUGIN_VERSION = "1.0.2" // Version fixe du plugin
    }

    lateinit var messagesConfig: YamlConfiguration
        private set

    private var token: String? = null
    private var isConfigFileCreated: Boolean = false
    private var isTokenValid: Boolean = false
    private var isPluginOperational: Boolean = true // Variable pour suivre l'état du plugin

    private var adGuard: AdGuard? = null // Ajout de l'instance d'AdGuard

    override fun onEnable() {
        setupMessages()
        logAndSendMessage(Level.INFO, "plugin_enabled")

        setupConfig()

        // Vérifier la version du plugin avant de continuer
        checkPluginVersion()

        if (isPluginOperational) {
            if (token != null) {
                validateTokenAndCheckAPI()
                if (isTokenValid) {
                    startRepeatingTasks()
                    adGuard = AdGuard(this) // Initialise AdGuard ici, quand le token est valide
                } else {
                    logAndSendMessage(Level.SEVERE, "token_non_valide")
                    logger.log(Level.SEVERE, "Token is invalid. Plugin will not run.")
                }
            } else {
                logAndSendMessage(Level.WARNING, "token_non_defini")
            }
        } else {
            logger.log(Level.SEVERE, "Le plugin n'est pas opérationnel en raison de la version obsolète.")
        }
    }

    override fun onDisable() {
        logAndSendMessage(Level.INFO, "plugin_disabled")
    }

    private fun setupConfig() {
        val configFile = File(dataFolder, "config.yml")

        if (!configFile.exists()) {
            saveResource("config.yml", false)
            if (!isConfigFileCreated) {
                logAndSendMessage(Level.INFO, "config_created")
                isConfigFileCreated = true
            }
        }

        val config = YamlConfiguration.loadConfiguration(configFile)
        token = config.getString("token", null)?.takeIf { it.isNotEmpty() }

        if (token == null) {
            logAndSendMessage(Level.WARNING, "token_non_defini")
        } else {
            logAndSendMessage(Level.INFO, "token_defini")
        }
    }

    private fun setupMessages() {
        val langCodes = listOf("fr", "en", "de", "pl", "po", "sp")

        langCodes.forEach { lang ->
            val messagesFile = File(dataFolder, "lang/messages_$lang.yml")
            if (!messagesFile.exists()) {
                saveResource("lang/messages_$lang.yml", false)
            }
        }

        val configFile = File(dataFolder, "config.yml")
        val config = YamlConfiguration.loadConfiguration(configFile)
        val lang = config.getString("language", "en") ?: "en"
        val messagesFile = File(dataFolder, "lang/messages_$lang.yml")

        messagesConfig = if (messagesFile.exists()) {
            YamlConfiguration.loadConfiguration(messagesFile)
        } else {
            YamlConfiguration.loadConfiguration(File(dataFolder, "lang/messages_en.yml"))
        }
    }

    private fun validateTokenAndCheckAPI() {
        val token = this.token ?: return

        val serverAddress = getPublicIp()
        val serverPort = Bukkit.getServer().port
        val serverVersion = Bukkit.getVersion() // Récupère la version du serveur
        val apiUrl = "https://adnow.online/plugins/minecraft/api_token_check.php?token=$token&ip=$serverAddress&port=$serverPort&serverVersion=${URLEncoder.encode(serverVersion, "UTF-8")}&pluginVersion=$PLUGIN_VERSION&games=1"

        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(response)))
            val status = document.getElementsByTagName("status").item(0)?.textContent ?: "unknown"
            val message = document.getElementsByTagName("message").item(0)?.textContent ?: "No message"

            if (status == "success") {
                logAndSendMessage(Level.INFO, "token_valide: $message")
                isTokenValid = true
                checkAPI()
            } else {
                logAndSendMessage(Level.WARNING, "token_non_valide: $message")
                isTokenValid = false
            }
        } catch (e: Exception) {
            logAndSendMessage(Level.WARNING, "api_request_error")
            logger.log(Level.WARNING, "An error occurred during the API request.", e)
            isTokenValid = false
        }
    }


    private fun getPublicIp(): String {
        return try {
            val url = URL("https://api.ipify.org?format=text")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val response = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
            connection.disconnect()
            response
        } catch (e: Exception) {
            "unknown_ip"
        }
    }

    private fun checkAPI() {
        val apiUrl = "https://adnow.online/plugins/minecraft/api_connect.php"
        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            if (response.contains("Database connection established")) {
                logAndSendMessage(Level.INFO, "api_connection_success")
            } else {
                logAndSendMessage(Level.WARNING, "api_connection_error")
            }
        } catch (e: Exception) {
            //logger.log(Level.WARNING, messagesConfig.getString("api_connection_error") ?: "Failed to connect to the API. Please check your network or API status.", e)
        }
    }

    private fun startRepeatingTasks() {
        object : BukkitRunnable() {
            override fun run() {
                requestAPI()
                fetchChatBotMessage()
            }
        }.runTaskTimer(this, 0L, 600L) // 600 ticks = 30 seconds
    }

    private fun requestAPI() {
        val token = this.token ?: return

        val apiUrl = "https://adnow.online/plugins/minecraft/get_server_commands.php?token=$token"
        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            executeCommands(response)
        } catch (e: Exception) {
            //logger.log(Level.WARNING, messagesConfig.getString("api_request_error") ?: "An error occurred during the API request.", e)
        }
    }

    private fun executeCommands(response: String) {
        try {
            val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(response)))
            val commandsNode = document.documentElement
            val status = commandsNode.getAttribute("status")

            if (status != "no-commands") {
                val commandNodes = commandsNode.getElementsByTagName("command")
                for (i in 0 until commandNodes.length) {
                    val command = commandNodes.item(i).textContent.trim()
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command)
                }
                logAndSendMessage(Level.INFO, "commands_executed")
            }
        } catch (e: Exception) {
            //logger.log(Level.WARNING, messagesConfig.getString("command_execution_error") ?: "An error occurred while executing commands from the API.", e)
        }
    }

    private fun fetchChatBotMessage() {
        val token = this.token ?: return

        val apiUrl = "https://adnow.online/plugins/minecraft/get_campagne_message.php?token=$token"
        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            if (response.isBlank()) {
                logger.warning("Empty response received from API.")
                return
            }

            val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(response)))
            val rootNode = document.documentElement

            val campaignNodes = rootNode.getElementsByTagName("campaign")
            if (campaignNodes.length == 0) {
                //logger.info("No campaigns found in response.")
            }

            for (i in 0 until campaignNodes.length) {
                val campaignNode = campaignNodes.item(i)
                val messageNodes = campaignNode.childNodes
                var campaignId: String? = null

                // Obtenir le campaign_id
                for (j in 0 until messageNodes.length) {
                    if (messageNodes.item(j).nodeName == "campaign_id") {
                        campaignId = messageNodes.item(j).textContent.trim()
                    }
                }

                for (j in 0 until messageNodes.length) {
                    if (messageNodes.item(j).nodeName == "chat_bot_message") {
                        val message = messageNodes.item(j).textContent.trim()
                        if (message.isNotBlank()) {
                            Bukkit.broadcastMessage("§6§l[§e#§lAD§6§l] §d- §f$message")

                            // Vérifier que campaignId est non nul avant d'appeler sendPlayerNamesToServer
                            if (campaignId != null) {
                                sendPlayerNamesToServer(token, campaignId)
                            } else {
                                //logger.warning("Campaign ID is missing in the response.")
                            }
                        } else {
                            //logger.warning("Empty chat_bot_message found.")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            //logger.log(Level.WARNING, messagesConfig.getString("chatbot_message_error") ?: "An error occurred while fetching ChatBot messages.", e)
        }
    }

    private fun sendPlayerNamesToServer(token: String, campaignId: String) {
        val playerNames = Bukkit.getOnlinePlayers().joinToString(",") { it.name }
        val apiUrl = "https://adnow.online/plugins/minecraft/send_player_names.php?token=$token&player_names=${URLEncoder.encode(playerNames, "UTF-8")}&campaign_id=$campaignId"

        try {
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connect()

            val responseCode = connection.responseCode
            val responseMessage = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            if (responseCode == HttpURLConnection.HTTP_OK) {
                //logger.info("Successfully sent player names to server: $responseMessage")
            } else {
                //logger.warning("Failed to send player names. Server responded with: $responseCode $responseMessage")
            }
        } catch (e: Exception) {
            //logger.log(Level.SEVERE, "An error occurred while sending player names to server.", e)
        }
    }

    private fun checkPluginVersion() {
        val versionUrl = "https://adnow.online/plugins/minecraft/get_plugin_version.php"
        try {
            val url = URL(versionUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            // Parser le XML pour obtenir la version
            val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(response)))
            val versionElement = document.getElementsByTagName("version").item(0)?.textContent
            val latestVersion = versionElement?.trim() ?: ""

            if (latestVersion != PLUGIN_VERSION) {
                logAndSendMessage(Level.SEVERE, "plugin_update_required")
                isPluginOperational = false
            }
        } catch (e: Exception) {
            logAndSendMessage(Level.WARNING, "api_request_error")
            isPluginOperational = false
        }
    }

    private fun logAndSendMessage(level: Level, messageKey: String) {
        val message = messagesConfig.getString(messageKey) ?: messageKey
        logger.log(level, message)
    }
}
